﻿namespace Polymorphism
{
    public class Message
    {
    }
}