﻿namespace MultipleInheritance
{
    public interface IDroppable
    {
        void Drop();
    }
}